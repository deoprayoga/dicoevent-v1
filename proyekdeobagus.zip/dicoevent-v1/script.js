
function renderEvents(events){
  const root = document.getElementById('event-list');
  root.innerHTML = '';
  if(!events.length){root.innerHTML='<p class="muted">Belum ada event.</p>';return;}
  events.forEach((e,i)=>{
    const div=document.createElement('div');
    div.className='event';
    div.innerHTML=`<div><strong>${e.title}</strong><div style="font-size:13px;color:#9aa4b2">${e.date} — ${e.place}</div></div>
                   <button data-i="${i}" class="btn-outline remove">Hapus</button>`;
    root.appendChild(div);
  });
}

function load(){
  const raw=localStorage.getItem('dico_events');
  return raw?JSON.parse(raw):[];
}

function save(events){
  localStorage.setItem('dico_events',JSON.stringify(events));
  renderEvents(events);
}

document.addEventListener('DOMContentLoaded',()=>{
  let events=load();
  renderEvents(events);

  document.getElementById('event-list').addEventListener('click',e=>{
    if(e.target.classList.contains('remove')){
      const i=+e.target.dataset.i;
      events.splice(i,1);
      save(events);
    }
  });

  document.getElementById('event-form').addEventListener('submit',e=>{
    e.preventDefault();
    const title=document.getElementById('title').value.trim();
    const date=document.getElementById('date').value;
    const place=document.getElementById('place').value.trim();
    if(!title||!date||!place)return alert('Isi semua kolom!');
    events.push({title,date,place});
    save(events);
    e.target.reset();
  });
});
