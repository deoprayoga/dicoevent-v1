
# DicoEvent — Versi 1 (Deo Bagus Prayoga)

Versi ini menambahkan form untuk membuat event baru langsung dari halaman.

## Fitur
- Tambah event dengan judul, tanggal, dan lokasi.
- Simpan data event di browser (localStorage).
- Hapus event satu per satu.
- Desain modern, ringan, dan responsif.

## Kontak
- **Nama:** Deo Bagus Prayoga
- **Email:** deobagus318@gmail.com
- **GitHub:** [github.com/deoprayoga](https://github.com/deoprayoga)
