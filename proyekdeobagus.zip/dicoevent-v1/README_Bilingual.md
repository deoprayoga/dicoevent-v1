# 🧩 DicoEvent Versi 1

## 🇮🇩 Deskripsi Submission (Bahasa Indonesia)

Proyek ini merupakan implementasi dari **DicoEvent Versi 1** yang dikembangkan oleh **Deo Bagus Prayoga** sebagai bagian dari tugas pada kelas *Belajar Membuat Aplikasi Web dengan Django* di Dicoding.

Aplikasi ini menampilkan halaman profil pribadi sekaligus fitur daftar acara (*event list*) sederhana. Pengguna dapat menambahkan event baru secara langsung melalui formulir yang tersedia, serta menghapus event yang tidak diperlukan. Semua data event disimpan secara lokal menggunakan **LocalStorage**, sehingga tetap tersimpan meskipun halaman direfresh.

---

### ✨ Fitur yang Diimplementasikan
1. **Halaman Profil Pengguna** — Menampilkan informasi singkat tentang pengembang, termasuk nama, alamat email, dan tautan GitHub.  
2. **Daftar Event Dinamis** — Pengguna dapat menambahkan event baru dengan judul, tanggal, dan lokasi.  
3. **Manajemen Event** — Tambah dan hapus event, dengan data tersimpan secara lokal (LocalStorage).  
4. **Desain Responsif dan Modern** — Tampilan ringan, adaptif, dan nyaman digunakan di berbagai ukuran layar.

---

### 💡 Teknologi yang Digunakan
- **HTML5** — Struktur dan konten halaman.  
- **CSS3** — Desain dan tata letak antarmuka.  
- **JavaScript (Vanilla)** — Logika interaksi dan penyimpanan data pada LocalStorage.  

---

### 📬 Informasi Pengembang
- **Nama:** Deo Bagus Prayoga  
- **Email:** [deobagus318@gmail.com](mailto:deobagus318@gmail.com)  
- **GitHub:** [https://github.com/deoprayoga](https://github.com/deoprayoga)  

---

## 🌍 Submission Description (English Version)

This project is an implementation of **DicoEvent Version 1**, developed by **Deo Bagus Prayoga** as part of the assignment for the *Belajar Membuat Aplikasi Web dengan Django* (Learning to Build a Web App with Django) course on Dicoding.

The application provides a personal profile page and a simple event list feature. Users can create new events directly through a form, and delete any event they no longer need. All event data is stored locally in the browser using **LocalStorage**, ensuring persistence even after the page is refreshed.

---

### ✨ Implemented Features
1. **User Profile Page** — Displays developer information, including name, email, and GitHub link.  
2. **Dynamic Event List** — Add new events with title, date, and location.  
3. **Event Management** — Add and delete events, with automatic data storage in LocalStorage.  
4. **Responsive & Modern Design** — Clean, adaptive layout suitable for all screen sizes.

---

### 💡 Technologies Used
- **HTML5** — Page structure and content.  
- **CSS3** — Styling and responsive layout.  
- **JavaScript (Vanilla)** — Event handling and data storage logic.

---

### 📬 Developer Information
- **Name:** Deo Bagus Prayoga  
- **Email:** [deobagus318@gmail.com](mailto:deobagus318@gmail.com)  
- **GitHub:** [https://github.com/deoprayoga](https://github.com/deoprayoga)
